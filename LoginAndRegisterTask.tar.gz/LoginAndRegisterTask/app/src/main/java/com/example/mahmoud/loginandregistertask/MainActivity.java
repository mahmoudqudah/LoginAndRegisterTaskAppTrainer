package com.example.mahmoud.loginandregistertask;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button bLogout;
    EditText etName,etUsername,etAge;
    ImageView imageView;
    TextView welcomMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = (ImageView)findViewById(R.id.imageBtn);

        bLogout =(Button)findViewById(R.id.logoutBtn);
        etName =(EditText)findViewById(R.id.nameE);
        etAge =(EditText)findViewById(R.id.ageE);
        etUsername =(EditText)findViewById(R.id.usernameE);
        welcomMessage = (TextView)findViewById(R.id.welcomMessageTV);


        bLogout.setOnClickListener(this);

        Intent intent =getIntent();
        String name = intent.getStringExtra("name");
        String age = intent.getStringExtra("age");
        String username = intent.getStringExtra("username");
        String message = name + " welcom user area";
        welcomMessage.setText(message);
        etAge.setText(age);
        etUsername.setText(username);
        etName.setText(name);



    }

    @Override
    public void onClick(View view) {


        switch (view.getId()){
            case R.id.logoutBtn:
                startActivity(new Intent(this , LoginActivity.class));

                break;

        }


    }
}
