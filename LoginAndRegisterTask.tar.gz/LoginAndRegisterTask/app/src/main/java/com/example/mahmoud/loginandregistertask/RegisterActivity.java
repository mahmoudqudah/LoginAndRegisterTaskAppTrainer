package com.example.mahmoud.loginandregistertask;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class RegisterActivity extends AppCompatActivity  {


    Button bRegister;
    EditText etName, etPassword,etUsername,etAge;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        imageView = (ImageView)findViewById(R.id.imageBtn);
        bRegister =(Button)findViewById(R.id.registerBtn);
        etName =(EditText)findViewById(R.id.nameEditText);
        etPassword =(EditText)findViewById(R.id.passwordEditText);
        etAge =(EditText)findViewById(R.id.ageEditText);
        etUsername =(EditText)findViewById(R.id.usernameEditText);

 bRegister.setOnClickListener(new View.OnClickListener() {
     @Override
     public void onClick(View view) {
         final String name =etName.getText().toString();
         final String username =etUsername.getText().toString();
         final String password =etPassword.getText().toString();
         final String age =etAge.getText().toString();

         Response.Listener<String> responselistener = new Response.Listener<String >(){
             @Override
             public void onResponse(String response) {
                 try {
                     JSONObject jsonResponse =new JSONObject(response);
                     boolean success = jsonResponse.getBoolean("success");

                     if(success){
                         Intent intent =new Intent(RegisterActivity.this , LoginActivity.class);
                         RegisterActivity.this.startActivity(intent);
                     }else
                     {
                         AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);
                         builder.setMessage("Register failed").setNegativeButton("Retry",null)
                                 .create().show();
                     }


                 } catch (JSONException e) {
                     e.printStackTrace();
                 }
             }
         };

         RegisterRequest registerRequest = new RegisterRequest(name,username,age,password, responselistener);

         RequestQueue queue = Volley.newRequestQueue(RegisterActivity.this);
         queue.add(registerRequest);
     }
 });


    }


}
